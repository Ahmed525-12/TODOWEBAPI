﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using TODOCore.Entites;

namespace TODOCore.Specfiction
{
    public class ReminderSpecf : BaseSpecifications<Reminders>
    {
        public ReminderSpecf(string userId) : base(
            (p => p.User_Id == userId)

            )
        {
        }
    }
}