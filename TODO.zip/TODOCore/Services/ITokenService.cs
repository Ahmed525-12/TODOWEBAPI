﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TODOCore.Entites;

namespace Talabat.Core.Services
{
    public interface ITokenService
    {
        public string CreateTokenAsync(AppUser user);
    }
}