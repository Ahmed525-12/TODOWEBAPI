﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TODOCore.Entites
{
    public class MonthOfEnter : BaseEntity
    {
        public MonthOfEnter()
        {
            Reminders = new HashSet<Reminders>();
        }

        public int num_month { get; set; }
        public ICollection<Reminders> Reminders { get; set; }
        public string User_Id { get; set; }
    }
}