﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TODOCore.Entites
{
    public class AppUser : IdentityUser
    {
        public int? DayOfEndMonth { get; set; }
        public string DisplayName { get; set; }
    }
}