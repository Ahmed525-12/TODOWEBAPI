﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace TODOCore.Entites
{
    public class Reminders : BaseEntity
    {
        public string title { get; set; }
        public string description { get; set; }
        public string User_Id { get; set; }

        //  [JsonIgnore]
        public MonthOfEnter MonthOfEnter { get; set; }

        [ForeignKey("MonthOfEnter")]
        public int MonthOfEnterId { get; set; }

        public DateTime Created_at { get; set; } = DateTime.Now;
    }
}