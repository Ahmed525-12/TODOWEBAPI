﻿using TODOCore.Entites;

namespace TODO.DTOS
{
    public class MonthOfEntercreaterDto
    {
        public int num_month { get; set; }
    }
}