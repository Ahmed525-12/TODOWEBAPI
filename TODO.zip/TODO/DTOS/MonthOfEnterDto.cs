﻿using TODOCore.Entites;

namespace TODO.DTOS
{
    public class MonthOfEnterDto
    {
        public int num_month { get; set; }
        public IReadOnlyList<RemindersDto> Reminders { get; set; }
        public string User_Id { get; set; }
    }
}