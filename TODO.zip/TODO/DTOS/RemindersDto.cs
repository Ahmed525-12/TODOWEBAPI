﻿using TODOCore.Entites;

namespace TODO.DTOS
{
    public class RemindersDto
    {
        public int Id { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public string User_Id { get; set; }
        public int MonthOfEnterId { get; set; }

        public DateTime Created_at { get; set; } = DateTime.Now;
    }
}