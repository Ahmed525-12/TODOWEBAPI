﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Talabat.PL.Errors;
using TODO.DTOS;
using TODOCore.Entites;
using TODOCore.Specfiction;
using TODOCore.Wrapper;
using ToDoRepository.Repos;

namespace TODO.Controllers
{
    public class MonthOfEnterController : BaseController
    {
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;
        private readonly UserManager<AppUser> _userManager;

        public MonthOfEnterController(IMapper mapper, IUnitOfWork unitOfWork, UserManager<AppUser> userManager)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
            _userManager = userManager;
        }

        [HttpPost("CreateMonthOfEnter")]
        public async Task<IActionResult> CreateMonthOfEnter(MonthOfEntercreaterDto monthOfEnterDto, string userEmail)
        {
            try
            {
                // Check if the monthOfEnterDto is null
                if (monthOfEnterDto == null)
                {
                    // Return a BadRequest response with an error message
                    return BadRequest(new ApiResponse(400, "Invalid request data."));
                }

                // Map the DTO to the monthOfEnterDto entity
                var mapped = _mapper.Map<MonthOfEntercreaterDto, MonthOfEnter>(monthOfEnterDto);

                // Check if the mapping failed
                if (mapped == null)
                {
                    // Return a BadRequest response with an error message
                    return BadRequest(new ApiResponse(400, "Failed to map RemindersDto to Reminders."));
                }
                var User = await _userManager.FindByEmailAsync(userEmail);

                var spec = new ReminderSpecf(mapped.User_Id);
                var reminders = await _unitOfWork.Repository<Reminders>().GetAllWithSpecAsync(spec);
                await _unitOfWork.CompleteAsync();
                var mmonthOfEnter = new MonthOfEnter()
                {
                    User_Id = User.Id,
                    num_month = mapped.num_month,
                    Reminders = (List<Reminders>)reminders,
                };
                if (User.DayOfEndMonth == DateTime.Today.Day)
                {
                    await _unitOfWork.Repository<MonthOfEnter>().AddAsync(mmonthOfEnter);
                    await _unitOfWork.CompleteAsync();
                }
                else
                {
                    return Ok(Result<MonthOfEnter>.Fail($"{DateTime.Today.Day} is not Equal {User.DayOfEndMonth} "));
                }
                // Add the reminders to the repository asynchronously

                return Ok(Result<MonthOfEnter>.Success(mmonthOfEnter, "Create successful"));
                // return Ok(new { message = "Create successful ", monthOfEnterDto });
            }
            catch (Exception ex)
            {
                // Return a more detailed error response
                // return StatusCode(500, new ApiResponse(500, "Internal server error"));
                return Ok(Result<MonthOfEnter>.Fail(ex.Message));
            }
        }

        [HttpGet("id")]
        public async Task<ActionResult<MonthOfEnter>> GetMonthOfEnterById(int id)
        {
            var monthOfEnter = await _unitOfWork.Repository<MonthOfEnter>().GetbyIdAsync(id);
            await _unitOfWork.CompleteAsync();
            if (monthOfEnter is null)
                return NotFound(new ApiResponse(404));
            var MappedProduct = _mapper.Map<MonthOfEnter, MonthOfEnterDto>(monthOfEnter);
            return Ok(MappedProduct);
        }

        [HttpDelete("id")]
        public async Task<IActionResult> DeleteMonthOfEnter(int id)
        {
            try
            {
                var monthOfEnter = await _unitOfWork.Repository<MonthOfEnter>().GetbyIdAsync(id);

                if (monthOfEnter == null)
                {
                    return NotFound(new ApiResponse(404, "Product not found"));
                }

                _unitOfWork.Repository<MonthOfEnter>().DeleteAsync(monthOfEnter);
                await _unitOfWork.CompleteAsync();  // Assuming that Complete() is the method that saves changes

                return Ok(new ApiResponse(200, "monthOfEnter deleted successfully"));
            }
            catch (Exception ex)
            {
                // Log the exception for troubleshooting

                // Return a more detailed error response
                return StatusCode(500, new ApiResponse(500, "Internal server error"));
            }
        }

        [HttpGet]
        public async Task<ActionResult<MonthOfEnterDto>> GetAllMonthOfEnter()
        {
            var monthOfEnter = await _unitOfWork.Repository<MonthOfEnter>().GetAllWithAsync();
            // await _unitOfWork.CompleteAsync();
            return Ok(monthOfEnter);
        }

        [HttpGet("UserID")]
        public async Task<ActionResult<MonthOfEnterDto>> GetAllUserMonthOfEnter(string UserID)
        {
            var spec = new MonthOfEnterSpecf(UserID);
            var monthOfEnter = await _unitOfWork.Repository<MonthOfEnter>().GetAllWithSpecAsync(spec);
            var MappedResult = _mapper.Map<List<MonthOfEnterDto>>(monthOfEnter);
            return Ok(Result<List<MonthOfEnterDto>>.Success(MappedResult));
        }

        [HttpPost("UpdateMonthOfEnter")]
        public async Task<ActionResult<MonthOfEnterDto>> UpdateReminders(MonthOfEnterDto monthOfEnterDto)
        {
            try
            {
                // Check if the monthOfEnterDto is null
                if (monthOfEnterDto == null)
                {
                    // Return a BadRequest response with an error message
                    return BadRequest(new ApiResponse(400, "Invalid request data."));
                }
                // Map the DTO to the Reminders entity
                var mapped = _mapper.Map<MonthOfEnterDto, MonthOfEnter>(monthOfEnterDto);

                // Check if the mapping failed
                if (mapped == null)
                {
                    // Return a BadRequest response with an error message
                    return BadRequest(new ApiResponse(400, "Failed to map monthOfEnterDto to Reminders."));
                }

                // update the reminders to the repository asynchronously
                _unitOfWork.Repository<MonthOfEnter>().Update(mapped);
                await _unitOfWork.CompleteAsync();

                return Ok(new { message = "Create successful ", monthOfEnterDto });
            }
            catch (Exception ex)
            {
                // Return a more detailed error response
                return StatusCode(500, new ApiResponse(500, "Internal server error"));
            }
        }
    }
}