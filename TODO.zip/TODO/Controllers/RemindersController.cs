﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Talabat.PL.Errors;
using TODO.DTOS;
using TODOCore.Entites;
using TODOCore.Specfiction;
using ToDoRepository.Repos;

namespace TODO.Controllers
{
    public class RemindersController : BaseController
    {
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public RemindersController(IMapper mapper, IUnitOfWork unitOfWork)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        [HttpPost("CreateReminders")]
        public async Task<ActionResult<RemindersDto>> CreateReminders(RemindersDto remindersDto)
        {
            try
            {
                // Check if the remindersDto is null
                if (remindersDto == null)
                {
                    // Return a BadRequest response with an error message
                    return BadRequest(new ApiResponse(400, "Invalid request data."));
                }

                // Map the DTO to the Reminders entity
                var mapped = _mapper.Map<RemindersDto, Reminders>(remindersDto);

                // Check if the mapping failed
                if (mapped == null)
                {
                    // Return a BadRequest response with an error message
                    return BadRequest(new ApiResponse(400, "Failed to map RemindersDto to Reminders."));
                }

                // Add the reminders to the repository asynchronously
                await _unitOfWork.Repository<Reminders>().AddAsync(mapped);
                await _unitOfWork.CompleteAsync();
                // Check if the reminders were successfully added

                // Map the created reminders back to DTO

                // Return the mapped DTO
                return Ok(new { message = "Create successful ", remindersDto });
            }
            catch (Exception ex)
            {
                // Log the exception details

                // Return a more detailed error response
                return StatusCode(500, new ApiResponse(500, "Internal server error"));
            }
        }

        [HttpGet("id")]
        public async Task<ActionResult<Reminders>> GetReminderById(int id)
        {
            var reminder = await _unitOfWork.Repository<Reminders>().GetbyIdAsync(id);
            await _unitOfWork.CompleteAsync();
            if (reminder is null)
                return NotFound(new ApiResponse(404));
            var MappedProduct = _mapper.Map<Reminders, RemindersDto>(reminder);
            return Ok(MappedProduct);
        }

        [HttpDelete("id")]
        public async Task<IActionResult> DeleteReminder(int id)
        {
            try
            {
                var reminder = await _unitOfWork.Repository<Reminders>().GetbyIdAsync(id);

                if (reminder == null)
                {
                    return NotFound(new ApiResponse(404, "Product not found"));
                }

                _unitOfWork.Repository<Reminders>().DeleteAsync(reminder);
                await _unitOfWork.CompleteAsync();  // Assuming that Complete() is the method that saves changes

                return Ok(new ApiResponse(200, "Reminders deleted successfully"));
            }
            catch (Exception ex)
            {
                // Log the exception for troubleshooting

                // Return a more detailed error response
                return StatusCode(500, new ApiResponse(500, "Internal server error"));
            }
        }

        [HttpGet]
        public async Task<ActionResult<RemindersDto>> GetAllProducts()
        {
            var reminders = await _unitOfWork.Repository<Reminders>().GetAllWithAsync();
            await _unitOfWork.CompleteAsync();
            return Ok(reminders);
        }

        [HttpGet("UserID")]
        public async Task<ActionResult<RemindersDto>> GetAllUserProducts(string UserID)
        {
            var spec = new ReminderSpecf(UserID);
            var reminders = await _unitOfWork.Repository<Reminders>().GetAllWithSpecAsync(spec);
            await _unitOfWork.CompleteAsync();
            return Ok(reminders);
        }

        [HttpPost("UpdateReminders")]
        public async Task<ActionResult<RemindersDto>> UpdateReminders(RemindersDto remindersDto)
        {
            try
            {
                // Check if the remindersDto is null
                if (remindersDto == null)
                {
                    // Return a BadRequest response with an error message
                    return BadRequest(new ApiResponse(400, "Invalid request data."));
                }
                // Map the DTO to the Reminders entity
                var mapped = _mapper.Map<RemindersDto, Reminders>(remindersDto);

                // Check if the mapping failed
                if (mapped == null)
                {
                    // Return a BadRequest response with an error message
                    return BadRequest(new ApiResponse(400, "Failed to map RemindersDto to Reminders."));
                }

                // update the reminders to the repository asynchronously
                _unitOfWork.Repository<Reminders>().Update(mapped);
                await _unitOfWork.CompleteAsync();

                return Ok(new { message = "Create successful ", remindersDto });
            }
            catch (Exception ex)
            {
                // Return a more detailed error response
                return StatusCode(500, new ApiResponse(500, "Internal server error"));
            }
        }
    }
}