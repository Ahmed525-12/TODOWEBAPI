﻿using Microsoft.AspNetCore.Mvc;

namespace TODO.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseController : ControllerBase
    {
    }
}