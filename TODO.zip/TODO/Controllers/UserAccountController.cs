﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Talabat.Core.Services;
using Talabat.PL.DTOs;
using Talabat.PL.Errors;
using TODO.DTOS;
using TODOCore.Entites;
using TODOCore.Wrapper;

namespace TODO.Controllers
{
    public class UserAccountController : BaseController
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly ITokenService _tokenService;

        public UserAccountController(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager, ITokenService tokenService)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _tokenService = tokenService;
        }

        // Register

        [HttpPost("Register")]
        public async Task<ActionResult<UserDto>> Register(RegisterDto registerDto)
        {
            if (CheckIfUserExist(registerDto.Email).Result.Value)
                return BadRequest(new ApiResponse(400, "This Email Is Already Exist"));

            var user = new AppUser()
            {
                DisplayName = registerDto.DisplayName,
                Email = registerDto.Email,
                UserName = registerDto.Email.Split('@')[0]
            };
            var Result = await _userManager.CreateAsync(user, registerDto.Password);

            if (!Result.Succeeded) return BadRequest(new ApiResponse(400));

            var ReturnedUser = new UserDto()
            {
                DisplayName = registerDto.DisplayName,
                Email = registerDto.Email,
                Token = _tokenService.CreateTokenAsync(user)
            };

            return Ok(ReturnedUser);
        }

        [HttpPost("UpdateUser")]
        public async Task<ActionResult<UserDto>> UpdateUser(string userEmail, int dayOfEndMonth)
        {
            var User = await _userManager.FindByEmailAsync(userEmail);
            if (User is null) return BadRequest(new ApiResponse(400, "User Not Found"));

            User.DayOfEndMonth = dayOfEndMonth;
            var Result = await _userManager.UpdateAsync(User);
            if (!Result.Succeeded) return BadRequest(new ApiResponse(400, "Update Failed"));
            return Ok(Result<UserDto>.Success("Update successful"));
        }

        [HttpPost("Login")]
        public async Task<ActionResult<UserDto>> Login(LoginDto loginDto)
        {
            var User = await _userManager.FindByEmailAsync(loginDto.Email);
            if (User is null) return Unauthorized(new ApiResponse(401, "User Not Found"));

            var Result = await _signInManager.CheckPasswordSignInAsync(User, loginDto.Password, false);
            if (!Result.Succeeded) return Unauthorized(new ApiResponse(401, "Password Is Wrong"));

            return Ok(new UserDto()
            {
                Email = User.Email,
                DisplayName = User.DisplayName,
                Token = _tokenService.CreateTokenAsync(User)
            });
        }

        [HttpPost("Logout")]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();

            return Ok(new { message = "Logout successful" });
        }

        [HttpGet("IsUserExist")]
        public async Task<ActionResult<bool>> CheckIfUserExist(string Email)
        {
            return await _userManager.FindByEmailAsync(Email) is not null;
        }
    }
}