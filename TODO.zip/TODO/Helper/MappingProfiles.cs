﻿using System.Security.Cryptography;
using AutoMapper;

using Talabat.PL.DTOs;
using TODO.DTOS;
using TODOCore.Entites;

namespace Talabat.PL.Helper
{
    public class MappingProfiles : Profile
    {
        public MappingProfiles()
        {
            CreateMap<Reminders, RemindersDto>().ReverseMap();
            CreateMap<MonthOfEnter, MonthOfEnterDto>().ReverseMap();
            CreateMap<MonthOfEnter, MonthOfEntercreaterDto>().ReverseMap();
        }
    }
}