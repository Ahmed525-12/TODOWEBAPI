using Microsoft.EntityFrameworkCore;
using Talabat.PL.Extensions;
using Talabat.PL.MiddleWare;
using TODO.Extensions;
using ToDoRepository.Data;
using ToDoRepository.Identity;

namespace TODO
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddDbContext<ToDoContext>(options =>
            {
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
            });
            builder.Services.AddDbContext<AppIdentityDbContext>(options =>
            {
                options.UseSqlServer(builder.Configuration.GetConnectionString("AppIdentityConnection"));
            });
            builder.Services.AddAplicationServices();
            builder.Services.AddIdentityServices(builder.Configuration);

            var app = builder.Build();
            using var Scoped = app.Services.CreateScope();
            var Services = Scoped.ServiceProvider;
            var LoggerFactor = Services.GetRequiredService<ILoggerFactory>();
            try
            {
                var DbContext = Services.GetRequiredService<ToDoContext>();
                await DbContext.Database.MigrateAsync();
            }
            catch (Exception ex)
            {
                var logger = LoggerFactor.CreateLogger<Program>();
                logger.LogError(ex, "error from migration");
            }
            // Configure the HTTP request pipeline.
            app.UseMiddleware<ExceptionMiddleWare>();

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }
            app.UseStatusCodePagesWithReExecute("/errors/{0}");
            app.UseHttpsRedirection();

            app.UseAuthentication();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}