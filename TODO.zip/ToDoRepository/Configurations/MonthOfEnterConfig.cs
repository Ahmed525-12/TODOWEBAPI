﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TODOCore.Entites;

namespace ToDoRepository.Configurations
{
    public class RemindersConfig : IEntityTypeConfiguration<Reminders>
    {
        public void Configure(EntityTypeBuilder<Reminders> builder)
        {
            //  builder.HasOne(p => p.MonthOfEnter).WithMany(p => p.Reminders).HasForeignKey(p => p.MonthOfEnterId);
        }
    }
}