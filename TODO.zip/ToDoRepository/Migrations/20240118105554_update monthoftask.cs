﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ToDoRepository.Migrations
{
    public partial class updatemonthoftask : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MyProperty",
                table: "MonthOfTask");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "MyProperty",
                table: "MonthOfTask",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
