﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ToDoRepository.Migrations
{
    public partial class Configurationsmonthandupdateuser_id : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MonthOfTask_Users_UserNameId",
                table: "MonthOfTask");

            migrationBuilder.DropIndex(
                name: "IX_MonthOfTask_UserNameId",
                table: "MonthOfTask");

            migrationBuilder.DropColumn(
                name: "UserNameId",
                table: "MonthOfTask");

            migrationBuilder.AlterColumn<string>(
                name: "User_Id",
                table: "MonthOfTask",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_MonthOfTask_User_Id",
                table: "MonthOfTask",
                column: "User_Id");

            migrationBuilder.AddForeignKey(
                name: "FK_MonthOfTask_Users_User_Id",
                table: "MonthOfTask",
                column: "User_Id",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MonthOfTask_Users_User_Id",
                table: "MonthOfTask");

            migrationBuilder.DropIndex(
                name: "IX_MonthOfTask_User_Id",
                table: "MonthOfTask");

            migrationBuilder.AlterColumn<int>(
                name: "User_Id",
                table: "MonthOfTask",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<string>(
                name: "UserNameId",
                table: "MonthOfTask",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_MonthOfTask_UserNameId",
                table: "MonthOfTask",
                column: "UserNameId");

            migrationBuilder.AddForeignKey(
                name: "FK_MonthOfTask_Users_UserNameId",
                table: "MonthOfTask",
                column: "UserNameId",
                principalTable: "Users",
                principalColumn: "Id");
        }
    }
}
