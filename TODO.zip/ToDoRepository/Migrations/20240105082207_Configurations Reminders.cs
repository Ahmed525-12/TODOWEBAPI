﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ToDoRepository.Migrations
{
    public partial class ConfigurationsReminders : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Task_Users_UserNameId",
                table: "Task");

            migrationBuilder.DropIndex(
                name: "IX_Task_UserNameId",
                table: "Task");

            migrationBuilder.DropColumn(
                name: "UserNameId",
                table: "Task");

            migrationBuilder.AlterColumn<string>(
                name: "User_Id",
                table: "Task",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_Task_User_Id",
                table: "Task",
                column: "User_Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Task_Users_User_Id",
                table: "Task",
                column: "User_Id",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Task_Users_User_Id",
                table: "Task");

            migrationBuilder.DropIndex(
                name: "IX_Task_User_Id",
                table: "Task");

            migrationBuilder.AlterColumn<int>(
                name: "User_Id",
                table: "Task",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<string>(
                name: "UserNameId",
                table: "Task",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Task_UserNameId",
                table: "Task",
                column: "UserNameId");

            migrationBuilder.AddForeignKey(
                name: "FK_Task_Users_UserNameId",
                table: "Task",
                column: "UserNameId",
                principalTable: "Users",
                principalColumn: "Id");
        }
    }
}
